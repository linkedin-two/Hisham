// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;
import 'dart:ui_web' as ui;
import 'package:flutter/material.dart';

// ─────────────────────────────────────────────────────────────────────────────
// UnifiedVideoPlayer  (WEB)
//
// Uses HtmlElementView with an <iframe> for all three source types:
//   'youtube' →  youtube.com/embed/<id>
//   'gdrive'  →  drive.google.com/file/d/<id>/preview
//   'mp4'     →  HTML5 <video> tag embedded in an iframe srcdoc
// ─────────────────────────────────────────────────────────────────────────────

class UnifiedVideoPlayer extends StatefulWidget {
  final String sourceType;
  final String? youtubeUrl;
  final String? googleDriveUrl;
  final String? videoFileUrl;
  final String? title;

  const UnifiedVideoPlayer({
    super.key,
    required this.sourceType,
    this.youtubeUrl,
    this.googleDriveUrl,
    this.videoFileUrl,
    this.title,
  });

  @override
  State<UnifiedVideoPlayer> createState() => _UnifiedVideoPlayerWebState();
}

class _UnifiedVideoPlayerWebState extends State<UnifiedVideoPlayer> {
  late final String _viewId;

  @override
  void initState() {
    super.initState();
    // Unique ID so multiple players don't clash
    _viewId = 'unified-video-${DateTime.now().microsecondsSinceEpoch}';
    _registerView();
  }

  String _buildYouTubeEmbedUrl(String url) {
    try {
      final uri = Uri.parse(url);
      String? videoId;
      if (uri.host.contains('youtu.be')) {
        videoId = uri.pathSegments.isNotEmpty ? uri.pathSegments.first : null;
      } else {
        videoId = uri.queryParameters['v'];
        if (videoId == null && url.contains('/embed/')) {
          // Already an embed URL
          return url;
        }
      }
      if (videoId != null && videoId.isNotEmpty) {
        return 'https://www.youtube.com/embed/$videoId?autoplay=1&rel=0';
      }
    } catch (_) {}
    return url;
  }

  String _buildGDrivePreviewUrl(String url) {
    try {
      if (url.contains('/file/d/')) {
        final fileId = url.split('/file/d/')[1].split('/')[0];
        return 'https://drive.google.com/file/d/$fileId/preview';
      }
      if (url.contains('id=')) {
        final uri = Uri.parse(url);
        final fileId = uri.queryParameters['id'] ?? '';
        if (fileId.isNotEmpty) {
          return 'https://drive.google.com/file/d/$fileId/preview';
        }
      }
    } catch (_) {}
    return url;
  }

  String _buildMp4IframeSrcdoc(String mp4Url) {
    // An srcdoc HTML5 video player embedded as an iframe
    return '''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #000; display: flex; align-items: center; justify-content: center; height: 100vh; }
  video { width: 100%; height: 100%; object-fit: contain; }
</style>
</head>
<body>
  <video controls autoplay controlsList="nodownload">
    <source src="$mp4Url" type="video/mp4">
    Your browser does not support the video tag.
  </video>
</body>
</html>''';
  }

  void _registerView() {
    String? iframeSrc;
    String? iframeSrcdoc;

    switch (widget.sourceType) {
      case 'youtube':
        iframeSrc = _buildYouTubeEmbedUrl(widget.youtubeUrl ?? '');
        break;
      case 'gdrive':
        iframeSrc = _buildGDrivePreviewUrl(widget.googleDriveUrl ?? '');
        break;
      case 'mp4':
        iframeSrcdoc = _buildMp4IframeSrcdoc(widget.videoFileUrl ?? '');
        break;
      default:
        break;
    }

    ui.platformViewRegistry.registerViewFactory(
      _viewId,
      (int id) {
        final frame = html.IFrameElement()
          ..style.border = 'none'
          ..style.width = '100%'
          ..style.height = '100%'
          ..allowFullscreen = true
          ..setAttribute('allow', 'autoplay; fullscreen; picture-in-picture');

        if (iframeSrcdoc != null) {
          frame.srcdoc = iframeSrcdoc;
        } else if (iframeSrc != null) {
          frame.src = iframeSrc;
        }

        return frame;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(
          widget.title ?? 'Video',
          style: const TextStyle(fontSize: 16, fontFamily: 'Poppins'),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        elevation: 0,
      ),
      body: widget.sourceType == 'none'
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.error_outline, color: Colors.white54, size: 56),
                  SizedBox(height: 16),
                  Text(
                    'No video source configured for this video.',
                    style: TextStyle(color: Colors.white70, fontFamily: 'Poppins'),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            )
          : HtmlElementView(viewType: _viewId),
    );
  }
}

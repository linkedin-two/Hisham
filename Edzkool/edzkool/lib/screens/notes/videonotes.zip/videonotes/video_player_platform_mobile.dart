import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:webview_flutter/webview_flutter.dart';

// ─────────────────────────────────────────────────────────────────────────────
// UnifiedVideoPlayer  (MOBILE — Android / iOS)
//
// Handles three source types:
//   'youtube'  → youtube_player_iframe  (cross-platform, works without tricks)
//   'gdrive'   → WebViewWidget          (webview_flutter renders Drive preview)
//   'mp4'      → VideoPlayerController  + Chewie  (network stream with seeking)
// ─────────────────────────────────────────────────────────────────────────────

class UnifiedVideoPlayer extends StatefulWidget {
  final String sourceType;       // 'youtube' | 'gdrive' | 'mp4' | 'none'
  final String? youtubeUrl;
  final String? googleDriveUrl;
  final String? videoFileUrl;    // absolute URL: https://…/media/videos/x.mp4
  final String? title;

  const UnifiedVideoPlayer({
    super.key,
    required this.sourceType,
    this.youtubeUrl,
    this.googleDriveUrl,
    this.videoFileUrl,
    this.title,
  });

  @override
  State<UnifiedVideoPlayer> createState() => _UnifiedVideoPlayerState();
}

class _UnifiedVideoPlayerState extends State<UnifiedVideoPlayer> {
  // YouTube
  YoutubePlayerController? _youtubeController;

  // Google Drive (WebView)
  WebViewController? _webViewController;

  // MP4
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  bool _mp4Loading = true;
  bool _mp4Error = false;
  String _mp4ErrorMessage = '';

  @override
  void initState() {
    super.initState();
    _initPlayer();
  }

  void _initPlayer() {
    switch (widget.sourceType) {
      case 'youtube':
        _initYouTube();
        break;
      case 'gdrive':
        _initGDrive();
        break;
      case 'mp4':
        _initMp4();
        break;
      default:
        break;
    }
  }

  // ── YouTube ──────────────────────────────────────────────────────────────
  void _initYouTube() {
    final url = widget.youtubeUrl ?? '';
    final videoId = YoutubePlayerController.convertUrlToId(url) ?? '';

    _youtubeController = YoutubePlayerController.fromVideoId(
      videoId: videoId,
      autoPlay: true,
      params: const YoutubePlayerParams(
        showControls: true,
        showFullscreenButton: true,
        mute: false,
        strictRelatedVideos: true,
      ),
    );
  }

  // ── Google Drive ─────────────────────────────────────────────────────────
  void _initGDrive() {
    final driveUrl = widget.googleDriveUrl ?? '';
    // Convert share/view URL to preview URL for embedding
    final previewUrl = _convertToPreviewUrl(driveUrl);

    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onUrlChange: (UrlChange change) {},
        ),
      )
      ..loadRequest(Uri.parse(previewUrl));
  }

  String _convertToPreviewUrl(String url) {
    // https://drive.google.com/file/d/FILE_ID/view   →   /preview
    // https://drive.google.com/open?id=FILE_ID       →   /file/d/FILE_ID/preview
    try {
      final uri = Uri.parse(url);
      if (uri.host.contains('drive.google.com')) {
        if (url.contains('/file/d/')) {
          final parts = url.split('/file/d/');
          final fileId = parts[1].split('/')[0];
          return 'https://drive.google.com/file/d/$fileId/preview';
        }
        if (url.contains('id=')) {
          final fileId = uri.queryParameters['id'] ?? '';
          return 'https://drive.google.com/file/d/$fileId/preview';
        }
      }
    } catch (_) {}
    return url;
  }

  // ── MP4 (hosted in /media/) ───────────────────────────────────────────────
  Future<void> _initMp4() async {
    final url = widget.videoFileUrl ?? '';
    debugPrint('🎬 MP4 URL: $url');
    if (url.isEmpty) {
      setState(() {
        _mp4Error = true;
        _mp4Loading = false;
      });
      return;
    }

    try {
      _videoController = VideoPlayerController.networkUrl(Uri.parse(url));
      await _videoController!.initialize();

      _chewieController = ChewieController(
        videoPlayerController: _videoController!,
        autoPlay: true,
        looping: false,
        allowFullScreen: true,
        allowMuting: true,
        showControlsOnInitialize: true,
        placeholder: const Center(child: CircularProgressIndicator()),
      );

      setState(() {
        _mp4Loading = false;
      });
    } catch (e, st) {
      debugPrint('❌ Video error: $e\n$st');
      setState(() {
        _mp4Error = true;
        _mp4Loading = false;
        _mp4ErrorMessage = e.toString();
      });
    }
  }

  @override
  void dispose() {
    _youtubeController?.close();
    _chewieController?.dispose();
    _videoController?.dispose();
    // Restore portrait on dispose
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    super.dispose();
  }

  // ── BUILD ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(
          widget.title ?? 'Video',
          style: const TextStyle(fontSize: 16, fontFamily: 'Poppins'),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        elevation: 0,
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    switch (widget.sourceType) {
      case 'youtube':
        return _buildYouTube();
      case 'gdrive':
        return _buildGDrive();
      case 'mp4':
        return _buildMp4();
      default:
        return _buildError('No video source configured for this video.');
    }
  }

  Widget _buildYouTube() {
    if (_youtubeController == null) {
      return _buildError('Could not load YouTube video.');
    }
    return YoutubePlayerScaffold(
      controller: _youtubeController!,
      builder: (context, player) {
        return Center(child: player);
      },
    );
  }

  Widget _buildGDrive() {
    if (_webViewController == null) {
      return _buildError('Could not load Google Drive video.');
    }
    return SafeArea(
      child: WebViewWidget(controller: _webViewController!),
    );
  }

  Widget _buildMp4() {
    if (_mp4Loading) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: Color(0xFF008080)),
            SizedBox(height: 16),
            Text(
              'Loading video…',
              style: TextStyle(color: Colors.white70, fontFamily: 'Poppins'),
            ),
          ],
        ),
      );
    }
    if (_mp4Error || _chewieController == null) {
      return _buildError('Could not load video.\n\nError: $_mp4ErrorMessage');
    }
    return SafeArea(
      child: Chewie(controller: _chewieController!),
    );
  }

  Widget _buildError(String message) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, color: Colors.white54, size: 56),
            const SizedBox(height: 16),
            Text(
              message,
              style: const TextStyle(
                color: Colors.white70,
                fontFamily: 'Poppins',
                fontSize: 15,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

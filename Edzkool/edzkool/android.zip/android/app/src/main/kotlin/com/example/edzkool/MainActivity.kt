package com.example.edzkool

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

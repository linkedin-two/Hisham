// Main entry for EdVoyage Chat Flutter App
// Replaces the old static implementation with full backend integration

export 'chat_app.dart';
export 'screens/chat_entry_screen.dart';
export 'screens/conversations_screen.dart';
export 'screens/chat_screen.dart';
export 'screens/users_list_screen.dart';
export 'models/conversation_model.dart';
export 'models/message_model.dart';
export 'models/user_model.dart';
export 'providers/chat_provider.dart';

  late double _w;
  late double _h;
  late double _padH;
  late double _padV;
  late double _cardHPad;
  late double _cardVPad;
  late double _gapSm;
  late double _gapXs;
  late double _searchFieldH;
  late double _avatarSize;
  late double _actionBtnSize;
  late double _iconSm;
  late double _iconMd;
  late double _fsSm;
  late double _fsMd;
  late double _fsLg;

  @override
  void initState() {
    super.initState();
    _loadContacts();
    searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    searchController.removeListener(_onSearchChanged);
    searchController.dispose();
    _debounceTimer?.cancel();
    super.dispose();
  }

  /// Load contacts from JSON file
  Future<void> _loadContacts() async {
    try {
      setState(() {
        isLoading = true;
      });

      final String response =
          await rootBundle.loadString('lib/screens/chat/data.json');
      final List<dynamic> jsonData = json.decode(response);

      setState(() {
        allContacts = List<Map<String, dynamic>>.from(jsonData);
        filteredContacts = List.from(allContacts);
        isLoading = false;
      });
    } catch (e) {
      print('Error loading chat contacts: $e');
      setState(() {
        isLoading = false;
      });
    }
  }

  /// Debounced search functionality
  void _onSearchChanged() {
    if (_debounceTimer?.isActive ?? false) _debounceTimer!.cancel();
    _debounceTimer = Timer(Duration(milliseconds: 300), () {
      _filterContacts();
    });
  }

  /// Filter contacts based on search query
  void _filterContacts() {
    final query = searchController.text.toLowerCase().trim();

    setState(() {
      isSearching = query.isNotEmpty;

      if (query.isEmpty) {
        filteredContacts = List.from(allContacts);
      } else {
        filteredContacts = allContacts.where((contact) {
          final name = contact['name']?.toString().toLowerCase() ?? '';
          final role = contact['role']?.toString().toLowerCase() ?? '';
          final institution =
              contact['institution']?.toString().toLowerCase() ?? '';

          return name.contains(query) ||
              role.contains(query) ||
              institution.contains(query);
        }).toList();
      }
    });
  }

  /// Clear search and show all contacts
  void _clearSearch() {
    searchController.clear();
    setState(() {
      filteredContacts = List.from(allContacts);
      isSearching = false;
    });
  }

  /// Handle add contact action
  void _addContact(Map<String, dynamic> contact) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Added ${contact['name']} to contacts'),
        backgroundColor: primaryColor,
        duration: Duration(seconds: 2),
      ),
    );
  }

  /// Build search header with text field and cancel button
  Widget _buildSearchHeader() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: _padH, vertical: _padV),
      decoration: BoxDecoration(
        color: whiteColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          // Search Field
          Expanded(
            child: Container(
              height: _searchFieldH,
              decoration: BoxDecoration(
                color: grey1.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: TextField(
                controller: searchController,
                decoration: InputDecoration(
                  hintText: 'Search by name...',
                  hintStyle: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: _fsMd,
                    color: grey3,
                  ),
                  prefixIcon: Icon(
                    Icons.search,
                    color: grey3,
                    size: _iconSm,
                  ),
                  suffixIcon: searchController.text.isNotEmpty
                      ? GestureDetector(
                          onTap: _clearSearch,
                          child: Icon(
                            Icons.clear,
                            color: grey3,
                            size: _iconSm,
                          ),
                        )
                      : null,
                  border: InputBorder.none,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: _padH * 0.8, vertical: _padV * 0.8),
                ),
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: _fsMd,
                  color: titlecolor,
                ),
              ),
            ),
          ),
          SizedBox(width: (_w * 0.03).clamp(8.0, 14.0)),
          // Cancel Button
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(
                fontFamily: 'Poppins',
                fontSize: _fsLg,
                fontWeight: FontWeight.w600,
                color: primaryColor,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Build individual contact card
  Widget _buildContactCard(Map<String, dynamic> contact) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: _cardHPad, vertical: _cardVPad),
      decoration: BoxDecoration(
        color: whiteColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all((_w * 0.04).clamp(12.0, 18.0)),
        child: Row(
          children: [
            // Profile Image (Red Container)
            Container(
              width: _avatarSize,
              height: _avatarSize,
              decoration: BoxDecoration(
                color: Colors.red,
                borderRadius: BorderRadius.circular(_avatarSize / 2),
              ),
              child: Center(
                child: Icon(
                  Icons.person,
                  color: whiteColor,
                  size: (_avatarSize * 0.5).clamp(18.0, 26.0),
                ),
              ),
            ),
            SizedBox(width: (_w * 0.04).clamp(10.0, 18.0)),
            // Contact Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    contact['name'] ?? 'Unknown Contact',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: _fsLg,
                      fontWeight: FontWeight.w600,
                      color: titlecolor,
                    ),
                  ),
                  SizedBox(height: (_h * 0.006).clamp(2.0, 6.0)),
                  Text(
                    contact['role'] ?? 'No role specified',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: _fsMd,
                      color: grey3,
                    ),
                  ),
                  SizedBox(height: (_h * 0.004).clamp(2.0, 4.0)),
                  Text(
                    contact['institution'] ?? 'No institution specified',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: _fsSm,
                      color: grey3,
                    ),
                  ),
                ],
              ),
            ),
            // Add Button
            GestureDetector(
              onTap: () => _addContact(contact),
              child: Container(
                width: _actionBtnSize,
                height: _actionBtnSize,
                decoration: BoxDecoration(
                  color: primaryColor,
                  borderRadius: BorderRadius.circular(_actionBtnSize / 2),
                ),
                child: Center(
                  child: Icon(
                    Icons.add,
                    color: whiteColor,
                    size: (_actionBtnSize * 0.5).clamp(16.0, 22.0),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Build loading widget
  Widget _buildLoadingWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(
            color: primaryColor,
            strokeWidth: 2,
          ),
          SizedBox(height: _gapSm),
          Text(
            'Loading contacts...',
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: _fsLg,
              color: grey3,
            ),
          ),
        ],
      ),
    );
  }

  /// Build empty state widget
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.search_off,
            size: _iconMd,
            color: grey3,
          ),
          SizedBox(height: _gapSm),
          Text(
            isSearching ? 'No contacts found' : 'No contacts available',
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: (_fsLg * 1.1).clamp(16.0, 20.0),
              fontWeight: FontWeight.w600,
              color: titlecolor,
            ),
          ),
          SizedBox(height: _gapXs),
          Text(
            isSearching
                ? 'Try searching with different keywords'
                : 'Contacts will appear here once loaded',
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: _fsMd,
              color: grey3,
            ),
          ),
        ],
      ),
    );
  }

  /// Build see more button
  Widget _buildSeeMoreButton() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: _padV),
      child: Center(
        child: GestureDetector(
          onTap: () {
            // TODO: Implement pagination or load more functionality
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Load more functionality coming soon!'),
                backgroundColor: primaryColor,
              ),
            );
          },
          child: Text(
            'See More',
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: _fsLg,
              fontWeight: FontWeight.w600,
              color: primaryColor,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    _w = size.width;
    _h = size.height;

    _padH = (_w * 0.05).clamp(12.0, 24.0);
    _padV = (_h * 0.02).clamp(10.0, 18.0);
    _cardHPad = (_w * 0.05).clamp(12.0, 24.0);
    _cardVPad = (_h * 0.01).clamp(6.0, 10.0);
    _gapSm = (_h * 0.02).clamp(10.0, 16.0);
    _gapXs = (_h * 0.01).clamp(6.0, 12.0);
    _searchFieldH = (_h * 0.06).clamp(42.0, 54.0);
    _avatarSize = (_w * 0.12).clamp(40.0, 52.0);
    _actionBtnSize = (_w * 0.1).clamp(36.0, 44.0);
    _iconSm = (_w * 0.05).clamp(18.0, 22.0);
    _iconMd = (_w * 0.16).clamp(44.0, 72.0);
    _fsSm = (_w * 0.03).clamp(12.0, 13.0);
    _fsMd = (_w * 0.035).clamp(13.0, 15.0);
    _fsLg = (_w * 0.04).clamp(15.0, 18.0);

    return Scaffold(
      backgroundColor: color3,
      body: SafeArea(
        child: Column(
          children: [
            // Search Header
            _buildSearchHeader(),
            // Search Results
            Expanded(
              child: isLoading
                  ? _buildLoadingWidget()
                  : filteredContacts.isEmpty
                      ? _buildEmptyState()
                      : ListView.builder(
                          padding: EdgeInsets.symmetric(vertical: 8),
                          itemCount: filteredContacts.length +
                              1, // +1 for See More button
                          itemBuilder: (context, index) {
                            if (index == filteredContacts.length) {
                              return _buildSeeMoreButton();
                            }
                            return _buildContactCard(filteredContacts[index]);
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

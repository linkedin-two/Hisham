import 'dart:async';
import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/conversation_model.dart';
import '../models/message_model.dart';
import '../models/user_model.dart';
import '../services/chat_api_service.dart';

// Provider for current user email
final currentUserEmailProvider = StateProvider<String>((ref) => '');

// Provider for chat API service
final chatApiServiceProvider = Provider<ChatApiService>((ref) {
  final email = ref.watch(currentUserEmailProvider);
  return ChatApiService(currentUserEmail: email);
});

// Provider for conversations list with auto-refresh
final conversationsProvider = StateNotifierProvider<ConversationsNotifier, AsyncValue<List<Conversation>>>((ref) {
  final apiService = ref.watch(chatApiServiceProvider);
  return ConversationsNotifier(apiService);
});

class ConversationsNotifier extends StateNotifier<AsyncValue<List<Conversation>>> {
  final ChatApiService _apiService;
  Timer? _refreshTimer;

  ConversationsNotifier(this._apiService) : super(const AsyncValue.loading()) {
    loadConversations();
    _startAutoRefresh();
  }

  Future<void> loadConversations() async {
    try {
      state = const AsyncValue.loading();
      final conversations = await _apiService.getConversations();
      
      // Merge with all users to show new users (no messages yet)
      final users = await _apiService.getAllUsers();
      final conversationEmails = conversations.map((c) => c.otherEmail).toSet();
      
      final newUsers = users
          .where((u) => !conversationEmails.contains(u.email))
          .map((u) => Conversation(
                otherEmail: u.email,
                otherName: u.name,
                isNew: true,
              ))
          .toList();
      
      final merged = [...conversations, ...newUsers];
      state = AsyncValue.data(merged);
    } catch (e, stack) {
      state = AsyncValue.error(e, stack);
    }
  }

  void _startAutoRefresh() {
    _refreshTimer?.cancel();
    _refreshTimer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (state.hasValue) {
        _silentRefresh();
      }
    });
  }

  Future<void> _silentRefresh() async {
    try {
      final conversations = await _apiService.getConversations();
      final users = await _apiService.getAllUsers();
      final conversationEmails = conversations.map((c) => c.otherEmail).toSet();
      
      final newUsers = users
          .where((u) => !conversationEmails.contains(u.email))
          .map((u) => Conversation(
                otherEmail: u.email,
                otherName: u.name,
                isNew: true,
              ))
          .toList();
      
      final merged = [...conversations, ...newUsers];
      state = AsyncValue.data(merged);
    } catch (e) {
      // Silent fail on auto-refresh
    }
  }

  List<Conversation> search(String query) {
    final all = state.value ?? [];
    if (query.isEmpty) return all;
    
    final lowerQuery = query.toLowerCase();
    return all.where((c) {
      return c.otherEmail.toLowerCase().contains(lowerQuery) ||
             c.otherName.toLowerCase().contains(lowerQuery) ||
             c.lastText.toLowerCase().contains(lowerQuery);
    }).toList();
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }
}

// Provider for messages in a specific conversation
final messagesProvider = StateNotifierProvider.family<MessagesNotifier, AsyncValue<List<Message>>, String>((ref, otherEmail) {
  final apiService = ref.watch(chatApiServiceProvider);
  return MessagesNotifier(apiService, otherEmail);
});

class MessagesNotifier extends StateNotifier<AsyncValue<List<Message>>> {
  final ChatApiService _apiService;
  final String _otherEmail;
  Timer? _refreshTimer;

  MessagesNotifier(this._apiService, this._otherEmail) : super(const AsyncValue.loading()) {
    loadMessages();
    _startAutoRefresh();
  }

  Future<void> loadMessages() async {
    try {
      state = const AsyncValue.loading();
      final messages = await _apiService.getMessages(_otherEmail);
      state = AsyncValue.data(messages);
    } catch (e, stack) {
      state = AsyncValue.error(e, stack);
    }
  }

  Future<void> sendMessage({String? text, File? image}) async {
    try {
      final message = await _apiService.sendMessage(
        toEmail: _otherEmail,
        text: text,
        image: image,
      );
      
      final current = state.value ?? [];
      state = AsyncValue.data([...current, message]);
    } catch (e, stack) {
      state = AsyncValue.error(e, stack);
    }
  }

  void _startAutoRefresh() {
    _refreshTimer?.cancel();
    _refreshTimer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (state.hasValue) {
        _silentRefresh();
      }
    });
  }

  Future<void> _silentRefresh() async {
    try {
      final messages = await _apiService.getMessages(_otherEmail);
      state = AsyncValue.data(messages);
    } catch (e) {
      // Silent fail
    }
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }
}

// Provider for all users (for new chat)
final usersProvider = FutureProvider<List<UserSimple>>((ref) async {
  final apiService = ref.watch(chatApiServiceProvider);
  return await apiService.getAllUsers();
});

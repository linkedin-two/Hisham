import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import '../_env/chat_env.dart';
import '../models/conversation_model.dart';
import '../models/message_model.dart';
import '../models/user_model.dart';

class ChatApiService {
  final String currentUserEmail;

  ChatApiService({required this.currentUserEmail});

  Map<String, String> get _headers => {
    'Content-Type': 'application/json',
  };

  // Get all conversations for current user
  Future<List<Conversation>> getConversations() async {
    final url = Uri.parse('${ChatApi.conversations}?email=${Uri.encodeComponent(currentUserEmail)}');
    
    final response = await http.get(url, headers: _headers);
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['status'] == true) {
        final conversations = (data['conversations'] as List)
            .map((e) => Conversation.fromJson(e))
            .toList();
        return conversations;
      }
      throw Exception(data['error'] ?? 'Failed to load conversations');
    }
    throw Exception('Failed to load conversations: ${response.statusCode}');
  }

  // Get messages with specific user
  Future<List<Message>> getMessages(String otherEmail) async {
    final url = Uri.parse(
      '${ChatApi.messages}?email=${Uri.encodeComponent(currentUserEmail)}&other_email=${Uri.encodeComponent(otherEmail)}'
    );
    
    final response = await http.get(url, headers: _headers);
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['status'] == true) {
        final messages = (data['messages'] as List)
            .map((e) => Message.fromJson(e, currentUserEmail))
            .toList();
        return messages;
      }
      throw Exception(data['error'] ?? 'Failed to load messages');
    }
    throw Exception('Failed to load messages: ${response.statusCode}');
  }

  // Send message (text + optional image)
  Future<Message> sendMessage({
    required String toEmail,
    String? text,
    File? image,
  }) async {
    final url = Uri.parse(ChatApi.send);
    
    final request = http.MultipartRequest('POST', url);
    
    // Add fields
    request.fields['from_email'] = currentUserEmail;
    request.fields['to_email'] = toEmail;
    if (text != null && text.isNotEmpty) {
      request.fields['text'] = text;
    }
    
    // Add image if provided
    if (image != null) {
      final file = await http.MultipartFile.fromPath(
        'image',
        image.path,
        contentType: MediaType('image', 'jpeg'),
      );
      request.files.add(file);
    }
    
    final streamedResponse = await request.send();
    final response = await http.Response.fromStream(streamedResponse);
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['status'] == true) {
        return Message.fromJson(data['message'], currentUserEmail);
      }
      throw Exception(data['error'] ?? 'Failed to send message');
    }
    throw Exception('Failed to send message: ${response.statusCode}');
  }

  // Get all users for starting new chats
  Future<List<UserSimple>> getAllUsers() async {
    final url = Uri.parse('${ChatApi.users}?email=${Uri.encodeComponent(currentUserEmail)}');
    
    final response = await http.get(url, headers: _headers);
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['status'] == true) {
        final users = (data['users'] as List)
            .map((e) => UserSimple.fromJson(e))
            .where((u) => u.email != currentUserEmail) // Exclude current user
            .toList();
        return users;
      }
      throw Exception(data['error'] ?? 'Failed to load users');
    }
    throw Exception('Failed to load users: ${response.statusCode}');
  }
}

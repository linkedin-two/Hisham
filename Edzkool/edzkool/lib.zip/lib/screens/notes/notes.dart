import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:edzkool/_env/env.dart';
import 'package:edzkool/screens/notes/logo.dart';
import 'package:edzkool/screens/notes/main.dart';
import 'package:edzkool/screens/notes/topbar.dart';
// VideoTopicsScreen
import 'package:edzkool/utils/colors/colors.dart';
import 'package:edzkool/utils/responsive.dart';
import 'package:edzkool/widgets/botttom_nav.dart';

// Data model for a Category
class Category {
  final int id;
  final String name;

  Category({required this.id, required this.name});

  factory Category.fromJson(Map<String, dynamic> json) {
    return Category(id: json['id'], name: json['name']);
  }
}

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  Measurements? size;
  bool isLoading = true;
  List<Category> categories = [];

  @override
  void initState() {
    super.initState();
    fetchCategories();
  }

  Future<void> fetchCategories({int maxRetries = 3}) async {
    int attempt = 0;
    Duration delay = const Duration(seconds: 1);
    String? lastError;

    while (attempt < maxRetries) {
      attempt++;
      debugPrint("🔄 Category fetch attempt $attempt/$maxRetries");

      try {
        final response = await http
            .get(Uri.parse("${BaseUrl.baseUrl}/notes/categories/"))
            .timeout(const Duration(seconds: 15));

        debugPrint("🔍 API Status: ${response.statusCode}");
        debugPrint("🔍 API Body: ${response.body}");

        if (response.statusCode == 200) {
          final Map<String, dynamic> responseData = jsonDecode(response.body);

          // Handle standardized API response format
          List<dynamic> data;
          if (responseData.containsKey('data') && responseData['data'] is List) {
            data = responseData['data'] as List<dynamic>;
            debugPrint("✅ Found ${data.length} categories in 'data' field");
          } else {
            debugPrint("❌ No 'data' field found. Keys: ${responseData.keys}");
            throw Exception('Invalid response format: expected list in data field');
          }

          final List<Category> tempCategories =
              data.map((json) => Category.fromJson(json)).toList();
          debugPrint("✅ Parsed ${tempCategories.length} categories");
          for (var c in tempCategories) {
            debugPrint("   - Category: id=${c.id}, name=${c.name}");
          }

          if (mounted) {
            setState(() {
              categories = _sortCategories(tempCategories);
              debugPrint("✅ After sorting: ${categories.length} categories");
              isLoading = false;
            });
          }
          return; // Success - exit retry loop
        } else {
          throw Exception('Failed to load categories: ${response.statusCode}');
        }
      } catch (e) {
        lastError = e.toString();
        debugPrint("❌ Error on attempt $attempt: $e");

        if (attempt < maxRetries) {
          debugPrint("⏳ Retrying in ${delay.inSeconds}s...");
          await Future.delayed(delay);
          delay = Duration(seconds: delay.inSeconds * 2); // Exponential backoff
        }
      }
    }

    // All retries exhausted
    debugPrint("❌ All $maxRetries attempts failed. Last error: $lastError");
    if (mounted) {
      setState(() {
        categories = [];
        isLoading = false;
      });
    }
  }

  List<Category> _sortCategories(List<Category> categories) {
    // Define the desired order for known categories
    final orderMap = {
      'Class One': 1,
      'Class Two': 2,
      'Class Three': 3,
      'Class Four': 4,
      'Class Five': 5,
      'Class Six': 6,
      'Class Seven': 7,
      'Class Eight': 8,
      'Class Nine': 9,
      'Class Ten': 10,
      'NEET UG': 11,
      'NEET PG': 12,
    };

    // Sort: known categories first (by order), then unknown (alphabetically)
    categories.sort((a, b) {
      final aOrder = orderMap[a.name];
      final bOrder = orderMap[b.name];
      
      if (aOrder != null && bOrder != null) {
        return aOrder.compareTo(bOrder);
      } else if (aOrder != null) {
        return -1; // a comes first (known category)
      } else if (bOrder != null) {
        return 1; // b comes first (known category)
      } else {
        // Both unknown - sort alphabetically
        return a.name.compareTo(b.name);
      }
    });

    return categories;
  }

  Widget buildCategoryCard(Category category) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    final marginH = w * 0.04;
    final marginV = h * 0.012;
    final cardHeight = h * 0.22;
    final titleSize = w * 0.055;
    final accentHeight = w * 0.04;

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NotesScreen(className: category.name),
          ),
        );
      },
      child: Card(
        elevation: 2,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16.0),
        ),
        margin: EdgeInsets.symmetric(vertical: marginV, horizontal: marginH),
        child: SizedBox(
          height: cardHeight,
          width: double.infinity,
          child: Column(
            children: [
              ListTile(
                title: Text(
                  category.name,
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: titleSize,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                trailing: const Icon(Icons.more_vert),
              ),
              const Expanded(child: SizedBox()),
              SizedBox(height: h * 0.02),
              Container(
                height: accentHeight,
                width: double.infinity,
                color: primaryColor,
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    size = Measurements(MediaQuery.of(context).size);

    return Theme(
      data: Theme.of(context).copyWith(
        textTheme: Theme.of(context).textTheme.apply(fontFamily: 'Poppins'),
      ),
      child: Scaffold(
        appBar: CustomLogoAppBar(),
        bottomNavigationBar: BottomButton(
          selectedIndex: 3,
          onTap: () {},
        ),
        body: Column(
          children: [
            Topbar(firstText: "Edzkool", secondText: "Notes"),
            Expanded(
              child: isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : categories.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Text(
                                'No categories available',
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.grey,
                                ),
                              ),
                              const SizedBox(height: 16),
                              ElevatedButton.icon(
                                onPressed: () {
                                  setState(() {
                                    isLoading = true;
                                  });
                                  fetchCategories();
                                },
                                icon: const Icon(Icons.refresh),
                                label: const Text('Retry'),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: primaryColor,
                                  foregroundColor: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.only(top: 10),
                          itemCount: categories.length,
                          itemBuilder: (context, index) {
                            return buildCategoryCard(categories[index]);
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

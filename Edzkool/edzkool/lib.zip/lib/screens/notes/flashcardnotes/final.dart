import 'package:flutter/material.dart';
import 'package:edzkool/screens/notes/logo.dart';
import 'package:edzkool/screens/notes/topbar.dart';
import 'data.dart';

class FlashcardsScreenFour extends StatefulWidget {
  final String description;
  final String subSubjectName;
  final String subjectName;
  final String categoryName;
  const FlashcardsScreenFour({
    super.key,
    required this.description,
    required this.subSubjectName,
    required this.subjectName,
    required this.categoryName,
  });

  @override
  State<FlashcardsScreenFour> createState() => _FlashcardsScreenFourState();
}

class _FlashcardsScreenFourState extends State<FlashcardsScreenFour> {
  List<Map<String, String>> _images = [];
  final PageController _pageController = PageController();
  int _currentIndex = 0;
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadImages();
  }

  Future<void> _loadImages() async {
    try {
      var data = await fetchFlashcards();

      if (data == null) {
        setState(() {
          _errorMessage = 'NULL';
          _isLoading = false;
        });
        return;
      }

      List<dynamic> jsonData;
      if (data is Map && data.containsKey('results')) {
        jsonData = data['results'];
      } else if (data is List) {
        jsonData = data;
      } else {
        jsonData = [];
      }

      final filtered = jsonData.where(
        (item) =>
            item['category'] != null &&
            item['category']['name'] == widget.categoryName &&
            item['subject_name'] == widget.subjectName &&
            item['sub_subject_name'] == widget.subSubjectName &&
            item['description'] == widget.description,
      );

      final List<Map<String, String>> tempImages = [];

      for (var i in filtered) {
        if (i['images'] != null) {
          for (var img in i['images']) {
            tempImages.add({
              'image': img['image'].toString(),
              'caption': img['caption'].toString(),
            });
          }
        }
      }

      if (tempImages.isEmpty) {
        setState(() {
          _errorMessage = 'NULL';
          _isLoading = false;
        });
        return;
      }

      setState(() {
        _images = tempImages;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'NULL';
        _isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (_errorMessage != null) {
      final w = MediaQuery.of(context).size.width;
      return Scaffold(
        appBar: CustomLogoAppBar(),
        body: Center(
          child: Text(
            _errorMessage!,
            style: TextStyle(
              fontFamily: 'Poppins',
              color: Colors.red,
              fontSize: w * 0.045,
            ),
          ),
        ),
      );
    }

    return Theme(
      data: Theme.of(context).copyWith(
        textTheme: Theme.of(context).textTheme.apply(fontFamily: 'Poppins'),
      ),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: CustomLogoAppBar(),
        body: _images.isEmpty
            ? const Center(child: Text("No images found for this description."))
            : Column(
                children: [
                  Topbar(
                    firstText: "Flash Card",
                    secondText: widget.description,
                  ),
                  Expanded(
                    child: PageView.builder(
                      controller: _pageController,
                      itemCount: _images.length,
                      onPageChanged: (index) {
                        setState(() {
                          _currentIndex = index;
                        });
                      },
                      itemBuilder: (context, index) {
                        final imageData = _images[index];
                        return _buildFlashcard(imageData);
                      },
                    ),
                  ),
                  _buildFooter(),
                ],
              ),
      ),
    );
  }

  Widget _buildFlashcard(Map<String, String> imageData) {
    final imageUrl = imageData['image'] ?? '';
    final caption = imageData['caption'] ?? '';
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    final captionSize = w * 0.045;
    final paddingOuter = w * 0.04;
    final paddingInner = w * 0.05;
    final imageErrorIconSize = w * 0.12;

    return Padding(
      padding: EdgeInsets.all(paddingOuter),
      child: Card(
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: Colors.grey.shade300),
        ),
        child: SingleChildScrollView(
          padding: EdgeInsets.all(paddingInner),
          child: Column(
            children: [
              SizedBox(height: h * 0.02),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  imageUrl,
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stackTrace) => Center(
                    child: Icon(
                      Icons.broken_image,
                      size: imageErrorIconSize,
                      color: Colors.grey,
                    ),
                  ),
                ),
              ),
              SizedBox(height: h * 0.012),
              Text(
                caption,
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: captionSize,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFooter() {
    bool isLastImage = _currentIndex == _images.length - 1;
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    final paddingH = w * 0.06;
    final paddingV = h * 0.02;
    final counterSize = w * 0.06;
    final buttonPaddingH = w * 0.08;
    final buttonPaddingV = h * 0.015;
    final buttonTextSize = w * 0.04;

    return Container(
      padding: EdgeInsets.symmetric(horizontal: paddingH, vertical: paddingV),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Colors.grey.shade300)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          ElevatedButton(
            onPressed: _currentIndex > 0
                ? () {
                    _pageController.previousPage(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeIn,
                    );
                  }
                : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF008080),
              padding: EdgeInsets.symmetric(
                horizontal: buttonPaddingH,
                vertical: buttonPaddingV,
              ),
            ),
            child: Text(
              'PREV',
              style: TextStyle(
                fontFamily: 'Poppins',
                fontWeight: FontWeight.bold,
                color: Colors.white,
                fontSize: buttonTextSize,
              ),
            ),
          ),
          Text(
            '${_currentIndex + 1} / ${_images.length}',
            style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.bold,
              fontSize: counterSize,
            ),
          ),
          ElevatedButton(
            onPressed: () {
              if (isLastImage) {
                Navigator.of(context).pop();
              } else {
                _pageController.nextPage(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeIn,
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF008080),
              padding: EdgeInsets.symmetric(
                horizontal: buttonPaddingH,
                vertical: buttonPaddingV,
              ),
            ),
            child: Text(
              isLastImage ? 'FINISH' : 'NEXT',
              style: TextStyle(
                fontFamily: 'Poppins',
                fontWeight: FontWeight.bold,
                color: Colors.white,
                fontSize: buttonTextSize,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:edzkool/utils/api_response_handler.dart';
import 'package:edzkool/utils/colors/colors.dart';
import 'package:edzkool/_env/env.dart';
import 'package:edzkool/screens/notes/logo.dart';
import 'package:edzkool/screens/notes/topbar.dart';

class ResponsiveQBankNotesScreen extends StatefulWidget {
  const ResponsiveQBankNotesScreen({super.key});

  @override
  _ResponsiveQBankNotesScreenState createState() =>
      _ResponsiveQBankNotesScreenState();
}

class _ResponsiveQBankNotesScreenState
    extends State<ResponsiveQBankNotesScreen> {
  late Future<List<Map<String, dynamic>>> qBankTopicsFuture;
  int _selectedIndex = 3; // Notes tab is active

  @override
  void initState() {
    super.initState();
    qBankTopicsFuture = fetchQBankTopics();
  }

  /// Fetches Q-Bank topics data from the API
  /// API Endpoint: GET /api/v1/notes/categories/q_bank/topics/
  Future<List<Map<String, dynamic>>> fetchQBankTopics() async {
    try {
      final response = await http.get(
        Uri.parse('${BaseUrl.baseUrl}/notes/categories/q_bank/topics/'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      );

      print(
        'Responsive Q-Bank Topics API Response Status: ${response.statusCode}',
      );
      print('Responsive Q-Bank Topics API Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final topics = ApiResponseHandler.parseListResponse(
          response.body,
          (json) => json,
        );
        print('Successfully fetched responsive Q-Bank topics from API');
        return topics;
      } else {
        print('API Error: ${response.statusCode} - ${response.body}');
        throw Exception('Failed to load Q-Bank topics: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching responsive Q-Bank topics: $e');
      // Return default data structure if API fails
      return [
        {
          'id': 1,
          'title': 'Anatomy Q-Bank',
          'description':
              'Comprehensive anatomy question bank for medical students',
          'modules_count': 18,
          'is_featured': true,
          'order': 1,
        },
        {
          'id': 2,
          'title': 'Physiology Q-Bank',
          'description': 'Physiology question bank and practice questions',
          'modules_count': 15,
          'is_featured': false,
          'order': 2,
        },
        {
          'id': 3,
          'title': 'Biochemistry Q-Bank',
          'description': 'Biochemistry question bank and molecular concepts',
          'modules_count': 20,
          'is_featured': false,
          'order': 3,
        },
        {
          'id': 4,
          'title': 'Pharmacology Q-Bank',
          'description': 'Drug mechanisms and therapeutic question bank',
          'modules_count': 22,
          'is_featured': false,
          'order': 4,
        },
        {
          'id': 5,
          'title': 'Pathology Q-Bank',
          'description': 'Disease mechanisms and diagnostic question bank',
          'modules_count': 16,
          'is_featured': false,
          'order': 5,
        },
        {
          'id': 6,
          'title': 'Microbiology Q-Bank',
          'description':
              'Microbial organisms and infectious disease question bank',
          'modules_count': 19,
          'is_featured': false,
          'order': 6,
        },
        {
          'id': 7,
          'title': 'Forensic Medicine Q-Bank',
          'description': 'Forensic science and toxicological question bank',
          'modules_count': 12,
          'is_featured': false,
          'order': 7,
        },
        {
          'id': 8,
          'title': 'Community Medicine Q-Bank',
          'description': 'Public health and community healthcare question bank',
          'modules_count': 14,
          'is_featured': false,
          'order': 8,
        },
      ];
    }
  }

  /// Builds individual Q-Bank topic cards
  Widget _buildQBankTopicCard(
    Map<String, dynamic> topic,
    BuildContext context,
  ) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    final marginH = w * 0.04;
    final marginV = h * 0.012;
    final paddingH = w * 0.045;
    final paddingTop = h * 0.018;
    final paddingBottom = h * 0.02;
    final titleSize = w * 0.055;
    final bodySize = w * 0.045;
    final accentHeight = w * 0.04;

    return Card(
      elevation: 2,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.0),
      ),
      margin: EdgeInsets.symmetric(horizontal: marginH, vertical: marginV),
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(
              paddingH,
              paddingTop,
              paddingH,
              paddingBottom,
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    topic['title'] ?? 'Unknown Topic',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: titleSize,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                ),
                SizedBox(width: w * 0.03),
                Text(
                  '${topic['modules_count'] ?? 0} Modules',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: bodySize,
                    fontWeight: FontWeight.w700,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: accentHeight,
            width: double.infinity,
            color: const Color(0xFF008080),
          ),
        ],
      ),
    );
  }

  /// Builds bottom navigation bar
  Widget _buildBottomNavigation(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isTablet = screenWidth > 600;

    return Container(
      height: isTablet ? 100 : 80,
      decoration: BoxDecoration(
        color: primaryColor,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(isTablet ? 25 : 20),
          topRight: Radius.circular(isTablet ? 25 : 20),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildNavItem(0, 'assets/frame.png', 'Profile', context),
          _buildNavItem(1, 'assets/diamonds.png', 'Diamond', context),
          _buildNavItem(2, 'assets/Group 98.png', 'Y', context),
          _buildNavItem(3, 'assets/book.png', 'Notes', context, isActive: true),
          _buildNavItem(4, 'assets/airplane.png', 'Travel', context),
        ],
      ),
    );
  }

  /// Builds individual navigation items
  Widget _buildNavItem(
    int index,
    String iconPath,
    String label,
    BuildContext context, {
    bool isActive = false,
  }) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isTablet = screenWidth > 600;

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedIndex = index;
        });
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ImageIcon(
            AssetImage(iconPath),
            color: isActive ? secondaryColor : whiteColor,
            size: isTablet ? 28 : 24,
          ),
          if (isActive)
            Container(
              margin: EdgeInsets.only(top: isTablet ? 6 : 4),
              height: isTablet ? 3 : 2,
              width: isTablet ? 25 : 20,
              decoration: BoxDecoration(
                color: secondaryColor,
                borderRadius: BorderRadius.circular(1),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    final isLandscape = w > h;

    return Theme(
      data: Theme.of(context).copyWith(
        textTheme: Theme.of(context).textTheme.apply(fontFamily: 'Poppins'),
      ),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: CustomLogoAppBar(),
        body: SafeArea(
          child: Column(
            children: [
              Topbar(firstText: 'Q-Bank', secondText: 'Topics'),
              Expanded(
                child: FutureBuilder<List<Map<String, dynamic>>>(
                  future: qBankTopicsFuture,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    if (snapshot.hasError) {
                      return Center(
                        child: Padding(
                          padding: EdgeInsets.all(w * 0.06),
                          child: Text(
                            'Failed to load content',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontSize: w * 0.045,
                              fontWeight: FontWeight.w600,
                              color: Colors.black54,
                            ),
                          ),
                        ),
                      );
                    }

                    final topics = snapshot.data ?? [];
                    if (topics.isEmpty) {
                      return Center(
                        child: Text(
                          'No topics found',
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontSize: w * 0.045,
                            fontWeight: FontWeight.w600,
                            color: Colors.black54,
                          ),
                        ),
                      );
                    }

                    if (isLandscape && w > 700) {
                      return GridView.builder(
                        padding: EdgeInsets.only(top: h * 0.01),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          childAspectRatio: 2.8,
                          crossAxisSpacing: w * 0.04,
                          mainAxisSpacing: h * 0.02,
                        ),
                        itemCount: topics.length,
                        itemBuilder: (context, index) {
                          return _buildQBankTopicCard(topics[index], context);
                        },
                      );
                    }

                    return ListView.builder(
                      padding: EdgeInsets.only(top: h * 0.01),
                      itemCount: topics.length,
                      itemBuilder: (context, index) {
                        return _buildQBankTopicCard(topics[index], context);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
